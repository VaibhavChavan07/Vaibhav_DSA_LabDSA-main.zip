Project:

Q1: Write a program of Balancing Brackets, use a suitable data structure to print whether the string entered is a Balanced Brackets or Unbalanced String

Sample input

( [ [ { } ] ] )

Sample Output

The entered String has Balanced Brackets

Sample Input

( [ [ { } ] ] ) )

Sample Output

The entered Strings do not contain Balanced Brackets

___________________________________________

Q2: Find a pair with a given sum in Binary Search Tree

40 /
20 60 / \ /
10 30 50 70
 
Sum = 130
Pair is (60,70)


If the sum is not found, print nodes are not found.

____________________________________________

Notes:
1. The main project folder includes both the questions answered in 2 separate folders with their individual packages and class files.
2. The code formatting is simple to make it more readable, easy to understand and maintain
